﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

[assembly: DoNotParallelize]
