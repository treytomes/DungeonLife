﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("ComputeSharp.Graphics")]
[assembly: InternalsVisibleTo("ComputeSharp.Shaders")]
