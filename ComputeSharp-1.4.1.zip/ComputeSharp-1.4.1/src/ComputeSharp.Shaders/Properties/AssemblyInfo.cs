﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("ComputeSharp")]
[assembly: InternalsVisibleTo("ComputeSharp.Tests.Internals")]
