﻿using System.Runtime.CompilerServices;

[assembly: InternalsVisibleTo("ComputeSharp")]
[assembly: InternalsVisibleTo("ComputeSharp.Shaders")]
[assembly: InternalsVisibleTo("ComputeSharp.Tests.Internals")]

